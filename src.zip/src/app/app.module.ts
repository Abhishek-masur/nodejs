import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EventComponent } from './event/event.component';
import { RegistrationComponent } from './registration/registration.component';
import { EventlistService } from './eventlist.service';
import { ListComponent } from './list/list.component';
@NgModule({
  declarations: [
    AppComponent,
    EventComponent,
    RegistrationComponent,
    ListComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [EventlistService],
  bootstrap: [AppComponent]
})
export class AppModule { }
