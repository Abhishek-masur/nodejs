import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { EventlistService } from '../eventlist.service';
@Component({
  selector: 'app-event',
  templateUrl: './event.component.html',
  styleUrls: ['./event.component.css']
})
export class EventComponent implements OnInit {
  public eve: any;
  constructor(public _route: Router, public event: EventlistService) {
    this.eve = this.event.events;
  }
  public isadded = false;
  ngOnInit(): void {
  }

  public events = [
    {
      Name: "Kannada Nityotsava",
      Date: "12/11/22",
      Venue: "BT Auditorium"
    },
    {
      Name: "FUN Week",
      Date: "5/11/22",
      Venue: "C-Lite"
    },
    {
      Name: "Auto-Expo Car Event",
      Date: "20/11/22",
      Venue: "Mechanical Department"
    }
  ]


  register() {
    this._route.navigate(["registration"]);
  }
  addevent(evename: any, date: any, ven: any) {
    const adminkey = prompt("Enter Your Admin KEY to ADD EVENT")
    if (adminkey != null) {
      if (parseInt(adminkey) == 20088) {
        this.event.add_to_event(evename.value, date.value, ven.value);
        this.isadded = !this.isadded;
        evename.value = "";
        date.value = "";
        ven.value = "";
      }
      else {
        alert("OOPs!!! You are Unauthorized to Add an event");
        evename.value = "";
        date.value = "";
        ven.value = "";
      }
    }
  }
}
