import { Component, OnInit } from '@angular/core';
import { EventlistService } from '../eventlist.service';
@Component({
  selector: 'app-list',
  templateUrl: './list.component.html',
  styleUrls: ['./list.component.css']
})
export class ListComponent implements OnInit {
  public listed: any;
  constructor(public stulist: EventlistService) {
    this.listed = this.stulist.List
  }

  ngOnInit(): void {
  }

}
