import { Injectable } from '@angular/core';
import { AnyCatcher } from 'rxjs/internal/AnyCatcher';

@Injectable({
  providedIn: 'root'
})
export class EventlistService {

  constructor() { }
  List = [{
    name: "Admin",
    dept: "CS",
    eve: "Fun week",
    div: 'B',
    usn: '01fe20bcs088'

  }];
  public count = 4;

  events = [
    {
      Name: "Kannada Nityotsava",
      EDate: "12/11/22",
      Venue: "BT Auditorium",
      EventNo: 1
    },
    {
      Name: "FUN Week",
      EDate: "5/11/22",
      Venue: "C-Lite",
      EventNo: 2
    },
    {
      Name: "Auto-Expo Car Event",
      EDate: "20/11/22",
      Venue: "Mechanical Department",
      EventNo: 3
    }
  ]

  add_to_list(na: any, dt: any, e: any, d: any, srn: any) {
    this.List.push({ name: na, dept: dt, eve: e, div: d, usn: srn });
  }

  add_to_event(evename: any, eve_data: any, eve_venue: any) {
    this.events.push({ Name: evename, EDate: eve_data, Venue: eve_venue, EventNo: this.count });
    this.count += 1;
  }


}

