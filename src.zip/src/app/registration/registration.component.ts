import { Component, OnInit } from '@angular/core';
import { EventlistService } from '../eventlist.service';
@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {

  public isdone = false;
  constructor(public stu: EventlistService) { }
  public na = '';
  public eve_name = '';
  ngOnInit(): void {
  }
  EveRegister(name: any, usn: any, div: any, dept: any, eve: any) {
    if (name.value == "" || usn.value == "" || div.value == "" || dept.value == "")
      alert("Enter Your Details Properly");
    else {
      this.na = name.value;
      this.eve_name = eve.value;
      this.isdone = !this.isdone;
    }
    this.stu.add_to_list(name.value, dept.value, eve.value, div.value, usn.value);
    dept.value = ""
    name.value = ""
    eve.value = ""
    div.value = ""
    usn.value = ""
  }

}
